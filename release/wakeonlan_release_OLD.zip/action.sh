#!/system/bin/sh

# Ativa manualmente o serviço principal
sh /data/adb/modules/WakePingModule/custom/wake_ping.sh
