#!/system/bin/sh

# Caminho para o script principal
#SCRIPT="/data/adb/modules/WakePingModule/#custom/wake_ping.sh"

# Verifica se o script está presente
#if [ -f "$SCRIPT" ]; then
#    chmod +x "$SCRIPT"
#    sh "$SCRIPT" #&
#else
#    echo "[WakePing] Script wake_ping.sh não #encontrado."
#fi



#!/system/bin/sh

# Configurações do usuário
MAC="0C:CC:47:E2:BD:FB"         # MAC do PC
IP="192.168.0.220"              # IP do PC
TIMEOUT=60                     # Tempo limite para ping
PING_CONFIRM=5                 # Pings adicionais após sucesso

# Caminho relativo para o binário wol
WOL_BIN="/data/adb/modules/WakePingModule/bin/wol"

# Garante que o binário tenha permissão de execução
chmod +x "$WOL_BIN"

# Envia pacote Wake-on-LAN
echo "[WakePing] Enviando pacote mágico para $MAC..."
"$WOL_BIN" "$MAC"

# Aguarda conexão via ping
echo "[WakePing] Testando conexão com $IP..."
SECONDS=0
while [ $SECONDS -lt $TIMEOUT ]; do
    if ping -c 1 -W 1 "$IP" > /dev/null; then
        echo "[WakePing] Conexão detectada!"
        break
    fi
    sleep 1
done

if [ $SECONDS -ge $TIMEOUT ]; then
    echo "[WakePing] Timeout de $TIMEOUT segundos. PC não respondeu."
    exit 1
fi

# Confirma com mais 5 pings
echo "[WakePing] Confirmando conexão com $PING_CONFIRM pings..."
SUCCESS=0
for i in $(seq 1 $PING_CONFIRM); do
    if ping -c 1 -W 1 "$IP" > /dev/null; then
        SUCCESS=$((SUCCESS+1))
    fi
    sleep 1
done

if [ $SUCCESS -eq $PING_CONFIRM ]; then
    echo "[WakePing] Conexão confirmada com sucesso!"
    exit 0
else
    echo "[WakePing] Falha na confirmação. Apenas $SUCCESS/$PING_CONFIRM pings bem-sucedidos."
    exit 1
fi

