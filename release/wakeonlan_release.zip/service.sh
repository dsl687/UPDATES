#!/system/bin/sh

# Caminho para o script principal
SCRIPT_PATH="/data/adb/modules/wakeonlan/packet_magic/wakeping.sh"

# Executa o script
sh "$SCRIPT_PATH"

