#!/system/bin/sh

# ============================
# Wake-on-LAN + Ping Verifier
# ============================

# 📍 Configurações do usuário
MAC="0C:CC:47:E2:BD:FB"                         # MAC do PC
IP_LIST="192.168.0.109 192.168.0.150"           # Lista de IPs possíveis
TIMEOUT=60                                      # Tempo limite total para ping (segundos)
PING_CONFIRM=5                                  # Número de pings adicionais após sucesso

# 📍 Caminho para o binário wakeonlan dentro do módulo Magisk
WOL_BIN="/data/adb/modules/wakeonlan/bin/wol"

# 🔐 Garante que o binário tenha permissão de execução
chmod +x "$WOL_BIN"

# 🚀 Envia pacote Wake-on-LAN
echo "[WakePing] Enviando pacote mágico para $MAC..."
"$WOL_BIN" "$MAC"

# 🕒 Aguarda conexão via ping alternando entre IPs
echo "[WakePing] Testando conexão com IPs possíveis..."
SECONDS=0
RESPONDING_IP=""

while [ "$SECONDS" -lt "$TIMEOUT" ]; do
    for IP in $IP_LIST; do
        echo "[WakePing] Tentando ping em $IP... (segundo $SECONDS)"
        if ping -c 1 -W 1 "$IP" > /dev/null; then
            echo "[WakePing] Conexão detectada com $IP!"
            RESPONDING_IP="$IP"
            break 2  # Sai dos dois loops
        fi
        sleep 1
    done
done

# ❌ Timeout sem resposta
if [ -z "$RESPONDING_IP" ]; then
    echo "[WakePing] Timeout de $TIMEOUT segundos. Nenhum IP respondeu."
    exit 1
fi

# ✅ Confirma com mais pings no IP que respondeu
echo "[WakePing] Confirmando conexão com $RESPONDING_IP usando $PING_CONFIRM pings..."
SUCCESS=0
for i in $(seq 1 "$PING_CONFIRM"); do
    echo "[WakePing] Ping #$i em $RESPONDING_IP..."
    if ping -c 1 -W 1 "$RESPONDING_IP" > /dev/null; then
        SUCCESS=$((SUCCESS + 1))
    fi
    sleep 1
done

# 🎯 Resultado final
if [ "$SUCCESS" -eq "$PING_CONFIRM" ]; then
    echo "[WakePing] Conexão confirmada com sucesso em $RESPONDING_IP!"
    exit 0
else
    echo "[WakePing] Falha na confirmação. Apenas $SUCCESS/$PING_CONFIRM pings bem-sucedidos em $RESPONDING_IP."
    exit 1
fi

