#!/system/bin/sh

# Ativa manualmente o serviço principal
sh /data/adb/modules/wakeonlan/packet_magic/magicpacket.sh
